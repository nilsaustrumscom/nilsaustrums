+++
weight = 3
date = "2014-07-11T10:54:24+02:00"
draft = false
title = "miesnieku"
desc = "Lorem ipsum dolor sit amet, consectetur adipisicing elit. More information, and even moreLorem ipsum dolor sit amet, consectetur adipisicing elit. More information, and even more"
location = "miesnieku"
architect = "Architect"
designer = "Nils Austrumss"
cooparation = "n/a"
tags    = [ "Interior" ]
slug = "miesnieku"
thumbnail = "images/projects/miesnieku/700/1.jpg"
+++

<img src="../../images/projects/miesnieku/1100/1.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/2.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/3.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/4.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/5.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/6.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/7.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/8.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/9.jpg" alt="miesnieku" title=""/>
<img src="../../images/projects/miesnieku/1100/10.jpg" alt="miesnieku" title=""/>

