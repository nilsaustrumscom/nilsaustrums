+++
weight = 1
date = "2014-07-11T10:54:24+02:00"
draft = false
title = "Ceriņu ielas dižnams, exterior, bla bla"
desc = "Lorem ipsum dolor sit amet, consectetur adipisicing elit. More information, and even moreLorem ipsum dolor sit amet, consectetur adipisicing elit. More information, and even more"
location = "Ceriņu iela etc"
architect = "Architect"
designer = "Nils Austrumss"
cooparation = "n/a"
tags    = [ "Interior" ]
slug = "cerinu"
thumbnail = "images/projects/cerinu/700/1.jpg"
+++

<img src="../../images/projects/cerinu/1100/1.jpg" alt="Cerinu" title=""/>
<img src="../../images/projects/cerinu/1100/2.jpg" alt="Cerinu" title=""/>
<img src="../../images/projects/cerinu/1100/3.jpg" alt="Cerinu" title=""/>
<img src="../../images/projects/cerinu/1100/4.jpg" alt="Cerinu" title=""/>

